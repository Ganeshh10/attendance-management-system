from django.db import models

# Create your models here.
class student(models.Model):
    name = models.CharField(max_length=35, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    rollno = models.CharField(max_length=35, null=True, blank=True)

class Attendance(models.Model):
    StudentName=models.CharField(max_length=35,null=True, blank=True) 
    date=models.DateField(max_length=35,null=True, blank=True)
    timeIn=models.TimeField(max_length=35,null=True, blank=True)
    timeOut=models.TimeField(max_length=35,null=True, blank=True)