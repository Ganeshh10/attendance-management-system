from django.shortcuts import render
from django.shortcuts import redirect, render
from .models import *
from django.contrib import messages
# Create your views here.
def create_student(request):
    if request.method == "POST":
        name = request.POST['name']
        dob = request.POST['dob']
        rollno = request.POST['rollno']
        emp_obj = student.objects.create(name=name,dob=dob,rollno=rollno)
        messages.success(request, "student created successfully")
        return redirect('students_list')
    return render(request, 'create_student.html')

def delete_student(request, pid):
    dta = student.objects.get(employeeid=pid)
    dta.delete()
    messages.success(request, "student Deleted successfully")
    return redirect('students_list')

def student_list(request):
    em_dta = student.objects.filter()
    bit = {'students':em_dta}
    return render(request, 'students_list.html',bit)