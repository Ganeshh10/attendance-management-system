from django.contrib import admin
from django.urls import path
from myapp import views



urlpatterns = [
    path('signup/',views.sign_up, name='signup'),
    path('login/',views.user_login, name='login'),
    path('logout/',views.user_logout,name='logout'),
    path('home/',views.home, name="home"),
    path('create-student',views.createEmployeee, name="create_student"),
    path('delete-student/<int:pid>',views.delete_employee, name="delete_student"),
    path('student-list',views.employee_list, name="students_list"),

    

]