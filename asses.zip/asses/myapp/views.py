from django.shortcuts import render, HttpResponseRedirect
from django.contrib import messages
from .forms import SignUpForm
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.shortcuts import redirect, render
from .models import *

# Create your views here.
def sign_up(request):
    if request.method == "POST":
        frm = SignUpForm(request.POST)
        if frm.is_valid():
            frm.save()
            return HttpResponse("Account Created Successfully!!")
    else:
        frm = SignUpForm()
    return render(request,'signup.html',{'form':frm})


def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fmr = AuthenticationForm(request=request,data=request.POST)
            if fmr.is_valid():
                uname = fmr.cleaned_data['username']
                upass = fmr.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged in successfully!!!')
                    return HttpResponseRedirect('/home/')
        else:
            fmr = AuthenticationForm()
        return render(request,'userlogin.html',{'form':fmr})
    else:
        return HttpResponseRedirect('/home/')


#Logout
def user_logout(request):
    logout(request)
    return HttpResponse("Logout Successful !!")

#forgotpassword
def forgotpassword(request):      
    return render(request,'forgotpassword.html',{})


def home(request):
    em_dta = student.objects.filter()
    onn_lve = em_dta.filter(on_leave=True)
    d = {'total_students':em_dta.count(), 'on_leave':onn_lve.count()}
    return render(request, 'dashboard.html',d)




def create_student(request):
    if request.method == "POST":
        name = request.POST['name']
        dob = request.POST['dob']
        rollno = request.POST['rollno']
        emp_obj = student.objects.create(name=name,dob=dob,rollno=rollno)
        messages.success(request, "student created successfully")
        return redirect('students_list')
    return render(request, 'create_student.html')

def delete_student(request, pid):
    dta = student.objects.get(employeeid=pid)
    dta.delete()
    messages.success(request, "student Deleted successfully")
    return redirect('students_list')

def student_list(request):
    em_dta = student.objects.filter()
    bit = {'students':em_dta}
    return render(request, 'students_list.html',bit)